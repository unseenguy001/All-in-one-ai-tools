document.addEventListener('DOMContentLoaded', function() {
    const toolListContainer = document.getElementById('tool-list');
    const searchInput = document.getElementById('searchInput');

    // Sample tool data (replace with your actual 100+ tools)
    const tools = [
        { name: "Image to PNG Converter", category: "Image Tools", url: "html/tools/image-to-png.html" },
        { name: "Word Counter", category: "Text Tools", url: "html/tools/word-counter.html" },
        { name: "Percentage Calculator", category: "Math & Calculators", url: "html/tools/percentage-calculator.html" },
        // Add more of your tools here following the same format
        // Example:
        // { name: "Image Resizer", category: "Image Tools", url: "html/tools/image-resizer.html" },
        // { name: "Character Counter", category: "Text Tools", url: "html/tools/character-counter.html" },
        // { name: "Age Calculator", category: "Math & Calculators", url: "html/tools/age-calculator.html" },
    ];

    function displayTools(toolsToDisplay) {
        toolListContainer.innerHTML = ''; // Clear previous list
        const categorizedTools = {};

        toolsToDisplay.forEach(tool => {
            if (!categorizedTools[tool.category]) {
                categorizedTools[tool.category] =;
            }
            categorizedTools[tool.category].push(tool);
        });

        for (const category in categorizedTools) {
            const categoryHeader = document.createElement('h2');
            categoryHeader.textContent = category;
            toolListContainer.appendChild(categoryHeader);

            const row = document.createElement('div');
            row.classList.add('row', 'row-cols-1', 'row-cols-sm-2', 'row-cols-md-3', 'g-4', 'mb-4');

            categorizedTools[category].forEach(tool => {
                const col = document.createElement('div');
                col.classList.add('col');
                const card = document.createElement('div');
                card.classList.add('card', 'h-100');
                const cardBody = document.createElement('div');
                cardBody.classList.add('card-body');
                const title = document.createElement('h5');
                title.classList.add('card-title');
                title.textContent = tool.name;
                const link = document.createElement('a');
                link.href = tool.url;
                link.classList.add('btn', 'btn-primary');
                link.textContent = 'Go to Tool';

                cardBody.appendChild(title);
                cardBody.appendChild(link);
                card.appendChild(cardBody);
                col.appendChild(card);
                row.appendChild(col);
            });
            toolListContainer.appendChild(row);
        }
    }

    function filterTools(searchTerm) {
        const filteredTools = tools.filter(tool =>
            tool.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        displayTools(filteredTools);
    }

    // Initial display of all tools
    displayTools(tools);

    // Search functionality
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.trim();
        filterTools(searchTerm);
    });
});
